package vivi.shapes;

import java.awt.Canvas;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.image.BufferStrategy;
import java.util.Random;

import javax.swing.JFrame;

@SuppressWarnings("serial")
public class Display extends Canvas implements Runnable {

	private Thread thread;
	private JFrame frame;
	private Random ran;
	
	public final static int WIDTH = 800, HEIGHT = 600;
	private static String title = "DVD Logo";
	private static boolean running = false;
	
	public Display() {
		this.frame = new JFrame();
		this.frame.setPreferredSize(new Dimension(WIDTH, HEIGHT));
		
	}
	
	public static void main(String[] args) {
		Display display = new Display();
		display.frame.setTitle(title);
		display.frame.add(display);
		display.frame.pack();
		display.frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		display.frame.setLocationRelativeTo(null);
		display.frame.setResizable(false);
		display.frame.setVisible(true);
		display.start();
	}
	
	public synchronized void start() {
		running = true;
		this.thread = new Thread(this, "Display");
		this.thread.start();
	}
	
	public synchronized void stop() {
		running = false;
		try {
			this.thread.join();
		} catch(InterruptedException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void run() {
		long lastTime = System.nanoTime();
		long timer = System.currentTimeMillis();
		final double ns = 1e9 / 60;
		double delta = 0;
		int frames = 0;
		
		while(running) {
			long now = System.nanoTime();
			delta += (now - lastTime) / ns;
			lastTime = now;
			while(delta >= 1) {
				update();
				delta--;
				render();
				frames++;
			}
			if(System.currentTimeMillis() - timer > 1000) {
				timer += 1000;
				this.frame.setTitle(title + " | " + frames + " FPS");
				frames = 0;
			}
		}
		stop();
	}
	
	int testing;
	int testing2;
	int testing3;
	int testing4;
	int testing5;
	int r, gg, b;
	int timer = 1000 / 50;
	Color color;
	boolean down = true, up = false, left = false, down2 = false;
	String world = "Hello World!";
	
	public void render() {
		if(testing3 == 0) { ran = new Random(); testing3 = ran.nextInt(HEIGHT) - 40; testing2 = testing3; color = Color.white; }
		BufferStrategy bs = this.getBufferStrategy();
		if(bs == null) {
			this.createBufferStrategy(3);
			return;
		}
		Graphics g = bs.getDrawGraphics();
		
		//Background
		g.setColor(Color.black);
		g.fillRect(-1, -1, WIDTH, HEIGHT);
		//Draw here!
		
		g.setColor(color);
		g.setFont(new Font("Comic Sans MS", 10, 20));
		g.drawString(world, testing, testing2);
//		System.out.println(testing + " | " + testing2);
		//End
		g.dispose();
		bs.show();
		//Up collisions
		if(testing2 >= HEIGHT - 40 && testing5 != 2) { left = false; down2 = false; down = false; up = true; testing4 = 0; }
		else if (testing2 >= HEIGHT - 40 && testing5 == 2) { left = true; down2 = false; down = false; up = false; testing4 = 1; }
		//Left collisions
		if(testing >= WIDTH - (world.length() * 10) && testing5 != 2 && testing5 != 1) { down = false; down2 = false; up = false; left = true; testing4 = 1; }
		else if(testing >= WIDTH - (world.length() * 10) && testing5 == 2) { down = true; down2 = false; up = false; left = false; testing4 = 3; }
		//Up2 collisions
		if(testing2 <= -1 && testing5 != 0 && testing5 != 3 && testing5 != 2) { left = false; down = false; up = false; down2 = true; testing4 = 2; }
		else if(testing2 <= -1 && testing5 == 0) { left = false; down = true; up = false; down2 = false; testing4 = 3; }
		//Down collisions
		if(testing <= -1 && testing5 != 0 && testing5 != 3) { left = false; up = false; down2 = false; down = true; testing4 = 3; }
		else if (testing <= -1 && testing5 == 0) { left = false; up = true; down2 = false; down = false; testing4 = 0; }
		//Sorry my code messy :)
		testing5 = testing4;
		if(down == true) { testing++; testing2++; }
		if(up == true) { testing++; testing2--; }
		if(left == true) { testing--; testing2--; }
		if(down2 == true) { testing--; testing2++; }
//		System.out.println("Down: " + down + " | Up: " + up + " | Left: " + left + " | Down2: " + down2 );
//		System.out.println("Last direction: " + testing5);
//		System.out.println("The timer: " + timer);
		timer--;
		if(timer <= 0) {
			r = ran.nextInt(256);
			gg = ran.nextInt(256);
			b = ran.nextInt(256);
			System.out.println("R: " + r + " GG: " + gg + "B: " + b);
			color = new Color(r, gg, b);
			timer = 1000 / 50;
		}
	}
	public void update() {}
}
